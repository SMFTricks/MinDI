<?php
// Version: 2.0; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'MinDi.<br /><br />Author: <a href="http://smftricks.com">SMF Tricks</a>. Design by <a href="http://www.simplemachines.org/community/index.php?action=profile;u=312371">buhthc</a>';

?>