<?php

$txt['sh_info'] = 'Information';

$txt['facebook_username'] = 'Facebook username';
$txt['twitter_username'] = 'Twitter username';
$txt['youtube_username'] = 'Youtube username';
$txt['rss_url'] = 'RSS URL';
$txt['sh_social_desc'] = 'Write the username or the id to show the button link in the footer.';
$txt['sh_any_com'] = 'There are no comments for this topic. Do you want to be the first?';
$txt['sh_topic_locked'] = 'Sorry, this topic is locked. Only admins and moderators can reply.';

$txt['sh_copy_own'] = 'Enter your own copyrights';
$txt['sh_copy_own_desc'] = 'HTML allowed';

$txt['sh_separate_sticky_locked'] = 'Separate the sticky topics and normal topics';
$txt['sh_this_fixed'] = 'Sticky Topics';
$txt['sh_this_normal'] = 'Normal Topics';

$txt['current_theme'] = 'Theme Settings';

?>