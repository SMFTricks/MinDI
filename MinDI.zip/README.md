# MinDI
Responsive theme for SMF
